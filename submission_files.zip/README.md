# AI Support Ticket Intelligence System

## Overview
This project is an end-to-end AI system designed to analyze customer support tickets. It provides automated anomaly detection, a natural language query interface, and a data visualization dashboard.

## Architecture
- **Frontend**: Streamlit for real-time data interaction.
- **Backend**: FastAPI for RESTful service exposure.
- **AI Engine**: LangChain integration for CSV-based Natural Language Understanding (Gemini 1.5 Flash).
- **Data Engine**: Pandas for ingestion, cleaning, and anomaly logic.

## Setup Instructions
1. Install dependencies: `pip install -r requirements.txt`
2. Run the API: `uvicorn main:app --reload`
3. Run the UI: `streamlit run app.py`

## Example Queries
- 'How many tickets are currently open?'
- 'What is the average customer rating for Technical category tickets?'
- 'Show me all Critical tickets not resolved within 12 hours.'
